const {
    DynamoDBClient
} = require("@aws-sdk/client-dynamodb");

const {
    DynamoDBDocumentClient,
    GetCommand,
    PutCommand
} = require("@aws-sdk/lib-dynamodb");

const client = new DynamoDBClient({
    region: "us-east-2"
});

const ddb = DynamoDBDocumentClient.from(client);

exports.handler = async (event) => {

    try {

        const body =
            JSON.parse(event.body);

        const result =
            await ddb.send(
                new GetCommand({
                    TableName: "vlr-cart",
                    Key: {
                        userId: String(body.userId)
                    }
                })
            );

        const cart =
            result.Item;

        if (!cart) {

            return {
                statusCode: 404,
                headers: {
                    "Access-Control-Allow-Origin": "*",
                    "Access-Control-Allow-Headers": "*",
                    "Access-Control-Allow-Methods": "PUT,OPTIONS"
                },
                body: JSON.stringify({
                    message: "Cart not found."
                })
            };

        }

        const item =
            cart.items.find(
                p =>
                    Number(p.productId) ===
                    Number(body.productId)
            );

        if (!item) {

            return {
                statusCode: 404,
                headers: {
                    "Access-Control-Allow-Origin": "*",
                    "Access-Control-Allow-Headers": "*",
                    "Access-Control-Allow-Methods": "PUT,OPTIONS"
                },
                body: JSON.stringify({
                    message: "Product not found in cart."
                })
            };

        }

        item.quantity =
            Number(body.quantity);

        cart.items =
            cart.items.filter(
                p => p.quantity > 0
            );

        await ddb.send(
            new PutCommand({
                TableName: "vlr-cart",
                Item: cart
            })
        );

        return {

            statusCode: 200,

            headers: {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Headers": "*",
                "Access-Control-Allow-Methods": "PUT,OPTIONS"
            },

            body: JSON.stringify(cart)

        };

    } catch (error) {

        console.error(error);

        return {

            statusCode: 500,

            headers: {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Headers": "*",
                "Access-Control-Allow-Methods": "PUT,OPTIONS"
            },

            body: JSON.stringify({
                message: error.message
            })

        };

    }

};