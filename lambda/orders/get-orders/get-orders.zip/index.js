const { DynamoDBClient } = require("@aws-sdk/client-dynamodb");

const {
    DynamoDBDocumentClient,
    QueryCommand
} = require("@aws-sdk/lib-dynamodb");

const client = new DynamoDBClient({
    region: "us-east-2"
});

const ddb = DynamoDBDocumentClient.from(client);

exports.handler = async (event) => {

    try {

        const userId =
            event.queryStringParameters?.userId;

        if (!userId) {

            return {

                statusCode: 400,

                headers: {
                    "Access-Control-Allow-Origin": "*"
                },

                body: JSON.stringify({

                    message: "userId is required."

                })

            };

        }

        const result =
            await ddb.send(

                new QueryCommand({

                    TableName: "vlr-orders",

                    IndexName: "userId-index",

                    KeyConditionExpression:
                        "userId = :userId",

                    ExpressionAttributeValues: {

                        ":userId": String(userId)

                    }

                })

            );

        return {

            statusCode: 200,

            headers: {
                "Access-Control-Allow-Origin": "*"
            },

            body: JSON.stringify(

                result.Items || []

            )

        };

    }
    catch (error) {

        console.error(error);

        return {

            statusCode: 500,

            headers: {
                "Access-Control-Allow-Origin": "*"
            },

            body: JSON.stringify({

                message: error.message

            })

        };

    }

};